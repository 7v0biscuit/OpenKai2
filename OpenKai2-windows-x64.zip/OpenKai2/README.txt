OpenKai2 Windows x64 development build

Extract the entire ZIP, then double-click OpenKai2.exe and select your
original Budokai 2 USA ISO. Keep the DLL files beside the executable.
No Python or compiler is needed to launch this bundle.

Command line: OpenKai2.exe "D:\Games\Budokai 2 USA.iso"
The ISO must be present at every launch. Its files are verified before
execution. Allow disk space for an extracted copy in
%LOCALAPPDATA%\OpenKai2\discs.

Startup log: %LOCALAPPDATA%\OpenKai2\logs\startup.log

Gameplay has been verified through completion in playtesting. Music
playback and mod tools remain in development. Completion records and
targeted automated checks are documented in the source repository.
Source and build instructions: https://github.com/7v0biscuit/OpenKai2
